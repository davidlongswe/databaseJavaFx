package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/*
 * ------- Program krav ------------
 *
 * Programmet ska ha ett kommandoradsbaserat eller grafiskt användargränssnitt,
 * vilket möjliggör för användaren att välja vilken funktionalitet som skall utföras.
 *
 * Man ska kunna lägga in (Insert) data i databasens tabell via programmet.
 * Man ska kunna uppdatera (Update) enskilda dataposter via programmet.
 * Man ska kunna ta bort (Delete) enskilda dataposter via programmet.
 * Man ska kunna läsa (Select) ifrån databasen in till objekt som representerar den lästa datan.
 * Programmet ska kunna skriva ut alla dataposter från databasen.
 */

public class Main extends Application {

    /*
     * https://docs.oracle.com/javafx/2/ui_controls/jfxpub-ui_controls.pdf (everything javafx)
     */

    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
        primaryStage.setTitle("Hello World");
        primaryStage.setScene(new Scene(root, 300, 275));
        primaryStage.show();
        //runSelectQuery();
        //runInsertQuery();
        //getKunderMedOrder();
        //getAntalILager();
    }

    /*TODO: 1. create method that connects to database.
            2. create method that closes database.
            3. create method that inserts into database
            4. create method that updates something in the database
            5. create method that deletes from the database
            5. create method that shows certain parts of the database
            6. create method that displays the whole database
    */



    public static void main(String[] args) {
        launch(args);
    }

    private static void runSelectQuery() {
        Connection dbConnection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try{
            Class.forName("org.mariadb.jdbc.Driver").getDeclaredConstructor().newInstance();
            System.out.println("JDBC-drivrutinerna hittades!");

            String url = "jdbc:mariadb://atlantis.informatik.umu.se/svph1910_db2_ht2020";
            String user = "svph1910_2020273";
            String password = "yvytynyny";
            try{
                dbConnection = DriverManager.getConnection(url, user, password);
                System.out.println("Anslutningen till databasen lyckades!");
                String strSql = "SELECT artbenamning, artpris FROM ws2_artikel ORDER BY artbenamning ASC";
                statement = dbConnection.createStatement();
                resultSet = statement.executeQuery(strSql);
                while (resultSet.next()){
                    System.out.println(resultSet.getString("artbenamning") + ", " + resultSet.getInt("artpris"));
                }
            }catch(SQLException sqlError){
                System.err.println("Ett fel har inträffat: " + sqlError);
            }

        }catch (Exception e) {
            System.err.println("JDBC-drivrutinerna hittades INTE!");
        }

        try{
            if (resultSet != null){
                resultSet.close();
            }
            if(statement != null){
                statement.close();
            }
            if(dbConnection != null){
                dbConnection.close();
            }
        }catch(SQLException sqlErr){
            System.err.println("Ett fel har uppstått: " + sqlErr);
        }
    }

    private static void runInsertQuery() {
        Connection dbConnection = null;
        Statement statement = null;
        int result;

        try{
            Class.forName("org.mariadb.jdbc.Driver").getDeclaredConstructor().newInstance();
            System.out.println("JDBC-drivrutinerna hittades!");

            String url = "jdbc:mariadb://atlantis.informatik.umu.se/svph1910_db2_ht2020";
            String user = "svph1910_2020273";
            String password = "yvytynyny";
            try{
                dbConnection = DriverManager.getConnection(url, user, password);
                System.out.println("Anslutningen till databasen lyckades!");
                String strSql = "INSERT INTO ws2_artikel (artikelnr, artbenamning, artgrupp, artpris) VALUES (7001, 'Yuccapalm', 'GRÖN VÄXT', 600) ";
                statement = dbConnection.createStatement();
                result = statement.executeUpdate(strSql);
                System.out.println(result + " rader påverkades!");
            }catch(SQLException sqlError){
                System.err.println("Ett fel har inträffat: " + sqlError);
            }

        }catch (Exception e) {
            System.err.println("JDBC-drivrutinerna hittades INTE!");
        }

        try{
            if(statement != null){
                statement.close();
            }
            if(dbConnection != null){
                dbConnection.close();
            }
        }catch(SQLException sqlErr){
            System.err.println("Ett fel har uppstått: " + sqlErr);
        }
    }

    private static void getKunderMedOrder() {
        Connection dbConnection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try{
            Class.forName("org.mariadb.jdbc.Driver").getDeclaredConstructor().newInstance();
            System.out.println("JDBC-drivrutinerna hittades!");

            String url = "jdbc:mariadb://atlantis.informatik.umu.se/svph1910_db2_ht2020";
            String user = "svph1910_2020273";
            String password = "yvytynyny";
            try{
                dbConnection = DriverManager.getConnection(url, user, password);
                System.out.println("Anslutningen till databasen lyckades!");
                String strSql = "SELECT ws2_kund.kfnamn, ws2_kund.kenamn, ws2_korder.ordernr, ws2_korder.orderdatum " +
                                "FROM ws2_kund NATURAL JOIN ws2_korder";
                statement = dbConnection.createStatement();
                resultSet = statement.executeQuery(strSql);
                while (resultSet.next()){
                    System.out.println(resultSet.getString("kfnamn") + ", " + resultSet.getString("kenamn") + ", " +
                           resultSet.getInt("ordernr") + ", " + resultSet.getDate("orderdatum"));
                }
            }catch(SQLException sqlError){
                System.err.println("Ett fel har inträffat: " + sqlError);
            }

        }catch (Exception e) {
            System.err.println("JDBC-drivrutinerna hittades INTE!");
        }

        try{
            if (resultSet != null){
                resultSet.close();
            }
            if(statement != null){
                statement.close();
            }
            if(dbConnection != null){
                dbConnection.close();
            }
        }catch(SQLException sqlErr){
            System.err.println("Ett fel har uppstått: " + sqlErr);
        }
    }

    private static void getAntalILager() {
        Connection dbConnection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try{
            Class.forName("org.mariadb.jdbc.Driver").getDeclaredConstructor().newInstance();
            System.out.println("JDBC-drivrutinerna hittades!");

            String url = "jdbc:mariadb://atlantis.informatik.umu.se/svph1910_db2_ht2020";
            String user = "svph1910_2020273";
            String password = "yvytynyny";
            try{
                dbConnection = DriverManager.getConnection(url, user, password);
                System.out.println("Anslutningen till databasen lyckades!");
                String strSql = "SELECT ws2_kund.kfnamn, ws2_kund.kenamn, ws2_korder.ordernr, ws2_korder.orderdatum " +
                        "FROM ws2_kund NATURAL JOIN ws2_korder";
                statement = dbConnection.createStatement();
                resultSet = statement.executeQuery(strSql);
                while (resultSet.next()){
                    System.out.println(resultSet.getString("kfnamn") + ", " + resultSet.getString("kenamn") + ", " +
                            resultSet.getInt("ordernr") + ", " + resultSet.getDate("orderdatum"));
                }
            }catch(SQLException sqlError){
                System.err.println("Ett fel har inträffat: " + sqlError);
            }

        }catch (Exception e) {
            System.err.println("JDBC-drivrutinerna hittades INTE!");
        }

        try{
            if (resultSet != null){
                resultSet.close();
            }
            if(statement != null){
                statement.close();
            }
            if(dbConnection != null){
                dbConnection.close();
            }
        }catch(SQLException sqlErr){
            System.err.println("Ett fel har uppstått: " + sqlErr);
        }
    }
}
